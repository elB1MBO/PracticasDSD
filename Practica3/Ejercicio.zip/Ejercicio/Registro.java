public class Registro {
    
}
