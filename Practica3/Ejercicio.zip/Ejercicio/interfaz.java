import java.rmi.Remote;
import java.rmi.RemoteException;

public interface interfaz extends Remote{
    //Devuelve el total de donaciones
    int getTotal() throws RemoteException;
    //Añade la donación
    void addDonacion(int donacion) throws RemoteException;
    
}
