import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.net.MalformedURLException;

public class Donacion extends UnicastRemoteObject implements interfaz{
    private int total_donado;

    public Donacion() throws RemoteException{}

    public int getTotal() throws RemoteException{
        return total_donado;
    }

    public void addDonacion(int donacion) throws RemoteException{
        total_donado+=donacion;
    }
}
